"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertPdfAHttpTrigger = convertPdfAHttpTrigger;
const conversion_1 = require("./services/conversion");
async function convertPdfAHttpTrigger(request, context) {
    const requestBody = (await request.json());
    try {
        const result = await (0, conversion_1.convertPdfA)(requestBody);
        return {
            status: 200,
            jsonBody: result
        };
    }
    catch (error) {
        context.log(`PDF conversion failure: ${String(error)}`);
        return {
            status: 500,
            jsonBody: {
                error: 'PDF conversion failed.'
            }
        };
    }
}
//# sourceMappingURL=convertA.js.map