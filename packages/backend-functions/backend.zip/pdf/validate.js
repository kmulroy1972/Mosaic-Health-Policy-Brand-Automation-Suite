"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validatePdfHttpTrigger = validatePdfHttpTrigger;
const validation_1 = require("./services/validation");
async function validatePdfHttpTrigger(request, context) {
    const requestBody = (await request.json());
    try {
        const result = await (0, validation_1.validatePdf)(requestBody);
        return {
            status: 200,
            jsonBody: result
        };
    }
    catch (error) {
        context.log(`PDF validation failure: ${String(error)}`);
        return {
            status: 500,
            jsonBody: {
                error: 'PDF validation failed.'
            }
        };
    }
}
//# sourceMappingURL=validate.js.map