import type { PdfValidationRequest, PdfValidationResponse } from '../types';
export declare function validatePdf(_request: PdfValidationRequest): Promise<PdfValidationResponse>;
//# sourceMappingURL=validation.d.ts.map