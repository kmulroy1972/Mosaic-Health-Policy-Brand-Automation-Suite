import type { PdfConversionRequest, PdfConversionResponse } from '../types';
export declare function convertPdfA(request: PdfConversionRequest): Promise<PdfConversionResponse>;
//# sourceMappingURL=conversion.d.ts.map