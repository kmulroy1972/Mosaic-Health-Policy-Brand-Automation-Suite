"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.convertPdfA = convertPdfA;
async function convertPdfA(request) {
    // TODO: integrate Ghostscript or Azure containerized service for PDF/A-2b conversion.
    return {
        pdfBase64: request.contentBase64,
        pdfa: request.convertToPdfA ?? false
    };
}
//# sourceMappingURL=conversion.js.map