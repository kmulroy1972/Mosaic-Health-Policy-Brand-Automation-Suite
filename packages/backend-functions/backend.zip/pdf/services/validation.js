"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validatePdf = validatePdf;
async function validatePdf(_request) {
    // TODO: integrate veraPDF or Azure containerized validator.
    return {
        pdfua: {
            passed: true,
            reportUrl: undefined
        },
        pdfa: {
            passed: true,
            reportUrl: undefined
        }
    };
}
//# sourceMappingURL=validation.js.map