"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.templatesHttpTrigger = templatesHttpTrigger;
const shared_brand_core_1 = require("@mhp/shared-brand-core");
const templates_1 = require("../graph/templates");
async function templatesHttpTrigger(_request, context) {
    const telemetry = (0, shared_brand_core_1.createTelemetryEnvelope)('templates_request', 'backend');
    try {
        const templates = await (0, templates_1.getTemplatesFromGraph)();
        const body = {
            items: templates
        };
        context.log(`Templates served: ${templates.length}`, telemetry.eventName);
        return {
            status: 200,
            jsonBody: body,
            headers: {
                'Content-Type': 'application/json'
            }
        };
    }
    catch (error) {
        context.log(`Failed to retrieve templates: ${String(error)}`);
        return {
            status: 500,
            jsonBody: {
                error: 'Failed to retrieve templates.'
            }
        };
    }
}
//# sourceMappingURL=httpTrigger.js.map