export {};
//# sourceMappingURL=httpTrigger.test.d.ts.map