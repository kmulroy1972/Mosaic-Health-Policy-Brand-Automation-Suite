import { GraphClient } from '@mhp/shared-brand-core';
export declare function getGraphClient(): GraphClient;
//# sourceMappingURL=client.d.ts.map