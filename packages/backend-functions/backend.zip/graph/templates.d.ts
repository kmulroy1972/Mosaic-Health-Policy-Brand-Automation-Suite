import type { TemplateItem } from '../templates/types';
export declare function getTemplatesFromGraph(): Promise<TemplateItem[]>;
//# sourceMappingURL=templates.d.ts.map