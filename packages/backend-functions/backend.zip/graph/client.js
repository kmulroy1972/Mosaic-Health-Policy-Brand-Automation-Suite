"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGraphClient = getGraphClient;
const identity_1 = require("@azure/identity");
const shared_brand_core_1 = require("@mhp/shared-brand-core");
const GRAPH_SCOPE = ['https://graph.microsoft.com/.default'];
let singleton = null;
let credential = null;
function resolveCredential() {
    if (process.env.GRAPH_ACCESS_TOKEN) {
        return null;
    }
    if (!credential) {
        credential = new identity_1.DefaultAzureCredential();
    }
    return credential;
}
async function acquireToken() {
    if (process.env.GRAPH_ACCESS_TOKEN) {
        return process.env.GRAPH_ACCESS_TOKEN;
    }
    const activeCredential = resolveCredential();
    if (!activeCredential) {
        throw new Error('No credential available for Microsoft Graph.');
    }
    const token = await activeCredential.getToken(GRAPH_SCOPE);
    if (!token?.token) {
        throw new Error('Failed to acquire Microsoft Graph token.');
    }
    return token.token;
}
function getGraphClient() {
    if (!singleton) {
        singleton = new shared_brand_core_1.GraphClient({
            getToken: acquireToken,
            userAgent: 'mhp-brand-automation/1.0'
        });
    }
    return singleton;
}
//# sourceMappingURL=client.js.map