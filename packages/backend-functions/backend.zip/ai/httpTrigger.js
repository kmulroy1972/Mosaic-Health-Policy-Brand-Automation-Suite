"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rewriteHttpTrigger = rewriteHttpTrigger;
const shared_brand_core_1 = require("@mhp/shared-brand-core");
const client_1 = require("./client");
const ALLOW_NON_AZURE_AI = process.env.ALLOW_NON_AZURE_AI === 'true';
const PII_MODE_ENABLED = process.env.ALLOW_PII_REWRITE === 'true';
const OPENAI_ENDPOINT = process.env.OPENAI_ENDPOINT ?? '';
async function rewriteHttpTrigger(request, context) {
    let body;
    try {
        body = (await request.json());
    }
    catch (error) {
        context.log('ai_rewrite_invalid_json', (0, shared_brand_core_1.redactSensitiveText)(String(error ?? 'unknown')));
        return {
            status: 400,
            jsonBody: { error: 'Invalid JSON payload.' }
        };
    }
    const validation = (0, shared_brand_core_1.validateRewriteRequest)(body);
    if (!validation.ok) {
        return {
            status: 400,
            jsonBody: { error: validation.error }
        };
    }
    const normalized = validation.value;
    const azureEndpoint = (0, shared_brand_core_1.isAzureOpenAIEndpoint)(OPENAI_ENDPOINT);
    if (normalized.piiMode) {
        if (!PII_MODE_ENABLED) {
            return {
                status: 400,
                jsonBody: { error: 'PII-related rewrites are not permitted.' }
            };
        }
        if (!azureEndpoint) {
            return {
                status: 400,
                jsonBody: { error: 'PII-related rewrites require Azure OpenAI.' }
            };
        }
    }
    if (!ALLOW_NON_AZURE_AI && !azureEndpoint) {
        return {
            status: 400,
            jsonBody: { error: 'Non-Azure AI providers are disabled.' }
        };
    }
    const start = Date.now();
    try {
        const response = await (0, client_1.rewriteText)(normalized);
        const elapsedMs = Date.now() - start;
        context.log('ai_rewrite_completed', (0, shared_brand_core_1.createRewriteTelemetry)({
            result: 'success',
            elapsedMs,
            piiMode: normalized.piiMode,
            provider: azureEndpoint ? 'azure' : 'other',
            modelId: response.modelId,
            promptTokens: response.tokenUsage?.promptTokens,
            completionTokens: response.tokenUsage?.completionTokens
        }));
        return {
            status: 200,
            jsonBody: response
        };
    }
    catch (error) {
        const elapsedMs = Date.now() - start;
        const errorMessage = error instanceof Error ? error.message : String(error ?? 'unknown');
        context.log('ai_rewrite_failed', (0, shared_brand_core_1.createRewriteTelemetry)({
            result: 'failure',
            elapsedMs,
            piiMode: normalized.piiMode,
            provider: azureEndpoint ? 'azure' : 'other',
            error: errorMessage
        }));
        return {
            status: 502,
            jsonBody: { error: 'Rewrite failed.' }
        };
    }
}
//# sourceMappingURL=httpTrigger.js.map