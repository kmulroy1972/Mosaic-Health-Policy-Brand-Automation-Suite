export declare function buildSystemPrompt(brandTerms?: string[]): string;
//# sourceMappingURL=prompt.d.ts.map