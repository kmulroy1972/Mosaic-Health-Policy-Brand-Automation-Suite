import type { RewriteRequest, RewriteResponse } from '@mhp/shared-brand-core';
export declare function rewriteText(request: RewriteRequest): Promise<RewriteResponse>;
//# sourceMappingURL=client.d.ts.map