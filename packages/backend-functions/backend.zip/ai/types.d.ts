export interface RewriteRequest {
    text: string;
    goal: Array<'concise' | 'formal' | 'lay-audience'>;
    tone: Array<'neutral' | 'professional'>;
    brandTerms?: string[];
    piiMode?: boolean;
}
export interface RewriteResponse {
    text: string;
    modelId: string;
    tokenUsage?: {
        promptTokens: number;
        completionTokens: number;
    };
}
//# sourceMappingURL=types.d.ts.map