import { HttpRequest, HttpResponseInit, InvocationContext } from '@azure/functions';
export declare function rewriteHttpTrigger(request: HttpRequest, context: InvocationContext): Promise<HttpResponseInit>;
//# sourceMappingURL=httpTrigger.d.ts.map