"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rewriteHttpTrigger = exports.validatePdfHttpTrigger = exports.convertPdfAHttpTrigger = exports.templatesHttpTrigger = exports.healthHttpTrigger = void 0;
var httpTrigger_1 = require("./health/httpTrigger");
Object.defineProperty(exports, "healthHttpTrigger", { enumerable: true, get: function () { return httpTrigger_1.healthHttpTrigger; } });
var httpTrigger_2 = require("./templates/httpTrigger");
Object.defineProperty(exports, "templatesHttpTrigger", { enumerable: true, get: function () { return httpTrigger_2.templatesHttpTrigger; } });
var convertA_1 = require("./pdf/convertA");
Object.defineProperty(exports, "convertPdfAHttpTrigger", { enumerable: true, get: function () { return convertA_1.convertPdfAHttpTrigger; } });
var validate_1 = require("./pdf/validate");
Object.defineProperty(exports, "validatePdfHttpTrigger", { enumerable: true, get: function () { return validate_1.validatePdfHttpTrigger; } });
var httpTrigger_3 = require("./ai/httpTrigger");
Object.defineProperty(exports, "rewriteHttpTrigger", { enumerable: true, get: function () { return httpTrigger_3.rewriteHttpTrigger; } });
//# sourceMappingURL=index.js.map